export class Data {
  username: string = "";
  password: string = "";
}
