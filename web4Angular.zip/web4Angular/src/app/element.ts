export class Element {
  x: string = "";
  y: string = "";
  r: string = "";
}
