import {
  InputText,
  InputTextModule
} from "./chunk-OW5CK5JO.js";
import "./chunk-3B5I2CTJ.js";
import "./chunk-GG5BJ3P3.js";
import "./chunk-GWLPIXA7.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
