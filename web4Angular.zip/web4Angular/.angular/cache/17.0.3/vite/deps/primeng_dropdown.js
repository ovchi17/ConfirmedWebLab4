import {
  DROPDOWN_VALUE_ACCESSOR,
  Dropdown,
  DropdownItem,
  DropdownModule
} from "./chunk-GSXTRFHV.js";
import "./chunk-4MYXCNFK.js";
import "./chunk-3SQF7L7O.js";
import "./chunk-PIRX6ED2.js";
import "./chunk-3B5I2CTJ.js";
import "./chunk-GG5BJ3P3.js";
import "./chunk-GWLPIXA7.js";
export {
  DROPDOWN_VALUE_ACCESSOR,
  Dropdown,
  DropdownItem,
  DropdownModule
};
//# sourceMappingURL=primeng_dropdown.js.map
